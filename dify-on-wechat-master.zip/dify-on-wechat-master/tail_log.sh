tail -f wechat_robot.log -n 20

