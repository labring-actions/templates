# Web channel
使用SSE（Server-Sent Events，服务器推送事件）实现，提供了一个默认的网页。也可以自己实现加入api

#使用方法
- 在配置文件中channel_type填入web即可
- 访问地址 http://localhost:9899
- port可以在配置项 web_port中设置
